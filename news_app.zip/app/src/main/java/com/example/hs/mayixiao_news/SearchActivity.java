package com.example.hs.mayixiao_news;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SearchActivity extends AppCompatActivity implements AdapterView.OnItemClickListener{
    public List<Map<String, String>> all_maps = new ArrayList<Map<String, String>>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Intent intent=getIntent();
        String message=intent.getStringExtra("search");
        findAll(message);
    }
    public void showList()
    {
        ListView listView =  findViewById(R.id.list2);
        SimpleAdapter simAdapt = new SimpleAdapter(
                this,
                all_maps,
                android.R.layout.simple_list_item_2,
                new String[]{"title", "date"},// 与下面数组元素要一一对应
                new int[]{android.R.id.text1, android.R.id.text2});
        listView.setAdapter(simAdapt);
        listView.setOnItemClickListener(this);
        listView.setSelection(0);
    }
    public void findAll(String message)
    {
        gather("maps_d",message);
        gather("maps_i",message);
        gather("maps_e",message);
        gather("maps_c",message);
        gather("maps_s",message);
        showList();
    }

    public  void gather(String filename,String message)
    {
        List<Map<String, String>> tem_List=new ArrayList<Map<String, String>>();
        File file = new File(getFilesDir(), filename);
        if (file.exists()) {
            try {
                FileInputStream inputStream=new FileInputStream(file);
                ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
               tem_List=(ArrayList<Map<String, String>>)objectInputStream.readObject();
                objectInputStream.close();
                inputStream .close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            for(Map map:tem_List)
            {
                if(map.get("title").toString().contains(message)) all_maps.add(map);
            }
        }
    }
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        String _link=null;
        view.setBackgroundColor(Color.parseColor("#FFDBD7D8"));
        _link=all_maps.get(position).get("link");
        Intent intent = new Intent();
        intent.setClass(this, ShowDescriptionActivity.class);
        intent.putExtra("address",_link);
        intent.putExtra("function",1);
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
