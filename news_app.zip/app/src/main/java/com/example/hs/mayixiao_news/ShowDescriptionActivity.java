package com.example.hs.mayixiao_news;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.example.hs.mayixiao_news.wxapi.WXEntryActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShowDescriptionActivity extends AppCompatActivity {
    public String link=null;
    private WebView webView;
    public int function=0;
    public String collection_title=null;
    public String collection_date=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_description);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();
        link = intent.getStringExtra("address");
        function = intent.getIntExtra("func", 0);
        collection_title = intent.getStringExtra("_title");
        collection_date = intent.getStringExtra("_date");
        WebView webview = findViewById(R.id.webView1);
        webview.loadUrl(link);
    }
    public void write_map(List map,String filename){

        //File file = new File(getFilesDir(), filename);
        FileOutputStream outputStream= null;
        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(map);
            objectOutputStream.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.collect, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if(id == R.id.share_weixin)
        {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.setType("image/jpg");
            intent.setType("text/*");
            intent.putExtra(Intent.EXTRA_STREAM, link);
            intent.putExtra(Intent.EXTRA_SUBJECT, collection_date);
            intent.putExtra(Intent.EXTRA_TEXT, collection_title);
            startActivity(Intent.createChooser(intent, "来自马奕潇_News"));
        }
        else if (id == R.id.delete) {
            List<Map<String, String>> tem_List=new ArrayList<Map<String, String>>();
            File file = new File(getFilesDir(), "maps_co");
            if (file.exists()) {
                try {
                    FileInputStream inputStream=new FileInputStream(file);
                    ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
                    tem_List=(ArrayList<Map<String, String>>)objectInputStream.readObject();
                    objectInputStream.close();
                    inputStream .close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                for(Map map:tem_List)
                {
                    if(map.get("address").equals(link)){ tem_List.remove(map);break; }
                }
                write_map(tem_List,"maps_co");
            }
            return true;
        }
        else if (id == R.id.collect&&function==1) {
            initView();
            List<Map<String, String>> tem_List=new ArrayList<Map<String, String>>();
            File file = new File(getFilesDir(), "maps_co");
            if (file.exists()) {
                try {
                    FileInputStream inputStream=new FileInputStream(file);
                    ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
                    tem_List=(ArrayList<Map<String, String>>)objectInputStream.readObject();
                    objectInputStream.close();
                    inputStream .close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                HashMap map = new HashMap<String, String>();
                map.put("title",collection_title);
                map.put("date",collection_date);
                map.put("address",link);
                if(!tem_List.contains(map)) tem_List.add(map);
                write_map(tem_List,"maps_co");
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void initView() {
        webView=findViewById(R.id.webView1);
        webView.requestFocus();
        initWebView();
    }

    @SuppressWarnings("deprecation")
    @SuppressLint("SetJavaScriptEnabled")
    private void initWebView() {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        // webView.getSettings().setBlockNetworkImage(true);// 把图片加载放在最后来加载渲染
        webView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        // 支持多窗口
        webView.getSettings().setSupportMultipleWindows(true);
        // 开启 DOM storage API 功能
        webView.getSettings().setDomStorageEnabled(true);
        // 开启 Application Caches 功能
        webView.getSettings().setAppCacheEnabled(true);
    }
}
