package com.example.hs.mayixiao_news;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.os.SystemClock;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.rometools.rome.feed.synd.SyndEntry;
import com.rometools.rome.feed.synd.SyndFeed;
import com.rometools.rome.io.FeedException;
import com.rometools.rome.io.SyndFeedInput;
import com.rometools.rome.io.XmlReader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private List<Map<String, String>> mapList_d = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> mapList_i = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> mapList_e = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> mapList_c = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> mapList_s = new ArrayList<Map<String, String>>();
    private List<Map<String, String>> mapList_r = new ArrayList<Map<String, String>>();
    public int labels[]={1,1,1,1,1};
    public int click_count[]={1,1,1,1,1,1};
    private SwipeRefreshLayout swipeRefreshLayout;
    public int index[]={0,0,0,0,0,0};
    public int state=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        //supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        findViewById(R.id.cate_domestic).setBackgroundColor(Color.parseColor("#FFE689AB"));
        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // 开始刷新，设置当前为刷新状态
                // 这里是主线程
                // TODO 获取数据
               new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        index[state]+=10;
                        switch(state)
                        {
                            case(1): if(mapList_d.size()!=0) showList(mapList_d,index[state]);break;
                            case(2): if(mapList_i.size()!=0)showList(mapList_i,index[state]);break;
                            case(3): if(mapList_e.size()!=0) showList(mapList_e,index[state]);break;
                            case(4): if(mapList_c.size()!=0) showList(mapList_c,index[state]);break;
                            case(5): if(mapList_s.size()!=0)showList(mapList_s,index[state]);break;
                            case(0): if(mapList_s.size()!=0)get_recommend();show_recommend();break;
                            default:break;
                        }
                        swipeRefreshLayout.setRefreshing(false);
                    }
                }, 1200);
            }
        });

        new Thread(runnable).start();
        new Thread(runnable2).start();
        state=1;

    }

    public void get_recommend()
    {
        mapList_r.clear();
        Random rand = new Random();
        while(mapList_r.size()<20)
        {
           int total=click_count[1]+click_count[2]+click_count[3]+click_count[4]+click_count[5];
           int i = rand.nextInt(total);
           if(i<click_count[1]) mapList_r.add(mapList_d.get(rand.nextInt(mapList_d.size())));
           else if(click_count[1]<=i&&i<click_count[1]+click_count[2])  mapList_r.add(mapList_d.get(rand.nextInt(mapList_i.size())));
           else if(click_count[1]+click_count[2]<=i&&i<click_count[1]+click_count[2]+click_count[3])
               mapList_r.add(mapList_d.get(rand.nextInt(mapList_e.size())));
           else if(click_count[1]+click_count[2]+click_count[3]<=i&&i<total-click_count[5])
               mapList_r.add(mapList_d.get(rand.nextInt(mapList_c.size())));
           else if(total-click_count[5]<=i&&i<total)
               mapList_r.add(mapList_d.get(rand.nextInt(mapList_s.size())));
        }
        return;
    }
    public void show_recommend()
    {
        ListView listView =  findViewById(R.id.list);
        SimpleAdapter simAdapt = new SimpleAdapter(
                this,
                mapList_r,
                android.R.layout.simple_list_item_2,
                new String[]{"title", "date"},// 与下面数组元素要一一对应
                new int[]{android.R.id.text1, android.R.id.text2});
        listView.setAdapter(simAdapt);
        listView.setOnItemClickListener(this);
        listView.setSelection(0);
    }
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            showList(mapList_d,index[1]);
            write_map(mapList_d,"maps_d");
        }
    };
    Handler handler2 = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            write_map(mapList_i,"maps_i");
            write_map(mapList_e,"maps_e");
            write_map(mapList_c,"maps_c");
            write_map(mapList_s,"maps_s");
            get_recommend();
        }
    };
    //新线程进行网络请求
    Runnable runnable = new Runnable(){
        @Override
        public void run() {
            getNews(mapList_d,"http://www.people.com.cn/rss/politics.xml");
            Message msg = new Message();
            handler.sendMessage(msg);
        }
    };
    Runnable runnable2 = new Runnable(){
        @Override
        public void run() {
            getNews(mapList_i,"http://www.people.com.cn/rss/world.xml");
            getNews(mapList_e,"http://www.people.com.cn/rss/finance.xml");
            getNews(mapList_c,"http://www.people.com.cn/rss/culture.xml");
            getNews(mapList_s,"http://www.people.com.cn/rss/sports.xml");
            Message msg = new Message();
            handler2.sendMessage(msg);
        }
    };
    public void write_map(List map,String filename)
    {
        FileOutputStream outputStream;
        try {
            outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            objectOutputStream.writeObject(map);
            objectOutputStream.close();
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void on_search_click(View view)
    {
        EditText editText = findViewById(R.id.editText2);
        String message = editText.getText().toString();
        Intent intent = new Intent(this,SearchActivity.class);
        intent.putExtra("search", message);
        startActivity(intent);
    }

    public void showList(List _mapList,int index)
    {
        List temList= new ArrayList<Map<String, String>>();
        if(index+10<=_mapList.size())
        {
            temList.addAll(_mapList.subList(0, index));
            temList.addAll(0,_mapList.subList(index,index+10 ));
        }
        else temList=_mapList;
        ListView listView =  findViewById(R.id.list);
        SimpleAdapter simAdapt = new SimpleAdapter(
                this,
                temList,
                android.R.layout.simple_list_item_2,
                new String[]{"title", "date"},// 与下面数组元素要一一对应
                new int[]{android.R.id.text1, android.R.id.text2});
        listView.setAdapter(simAdapt);
        listView.setOnItemClickListener(this);
        listView.setSelection(0);
    }
    public void getNews(List _maplist,String _url)
    {
        SyndFeed syndFeed = null;
        SyndFeedInput input = new SyndFeedInput();
        try {
            syndFeed = input.build(new XmlReader(new URL(_url)));
        } catch (FeedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<SyndEntry> entries = syndFeed.getEntries();
        if (entries != null && !entries.isEmpty()) {
            for (SyndEntry syndEntry : entries) {
                HashMap map = new HashMap<String, String>();
                map.put("title", syndEntry.getTitle());
                map.put("link", syndEntry.getLink());
                //map.put("description", syndEntry.getDescription());
                map.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm E").format(syndEntry.getPublishedDate()));
                //map.put("cate", syndEntry.getCategories());
                _maplist.add(map);
            }
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        String _link=null;
        String _title=null;
        String _date=null;
        int _position=position;
        if(_position>=10) _position-=10;
        else _position=index[state]+_position;
        view.setBackgroundColor(Color.parseColor("#FFDBD7D8"));
        click_count[state]++;
        switch(state)
        {
            case(1): _link=mapList_d.get(_position).get("link");
                    _title=mapList_d.get(_position).get("title");
                    _date=mapList_d.get(_position).get("date");break;
            case(2): _link=mapList_i.get(_position).get("link");
                    _title=mapList_i.get(_position).get("title");
                     _date=mapList_i.get(_position).get("date");break;
            case(3): _link=mapList_e.get(_position).get("link");
                _title=mapList_e.get(_position).get("title");
                _date=mapList_e.get(_position).get("date");break;
            case(4): _link=mapList_c.get(_position).get("link");
                _title=mapList_c.get(_position).get("title");
                _date=mapList_c.get(_position).get("date");break;
            case(5): _link=mapList_s.get(_position).get("link");
                _title=mapList_s.get(_position).get("title");
                _date=mapList_s.get(_position).get("date");break;
            case(0): _link=mapList_r.get(_position).get("link");
                _title=mapList_r.get(_position).get("title");
                _date=mapList_r.get(_position).get("date");break;
            default:break;
        }
        Intent intent = new Intent();
        intent.setClass(this, ShowDescriptionActivity.class);
        intent.putExtra("address",_link);
        intent.putExtra("func",1);
        intent.putExtra("_title",_title);
        intent.putExtra("_date",_date);
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        //menu.add(1,1, 1, "我的收藏");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.my_collections) {
            Intent intent = new Intent();
            intent.setClass(this, CollectionActivity.class);
            startActivity(intent);
            return true;
        }
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent();
            intent.setClass(this, LabelActivity.class);
            intent.putExtra("label",labels);
            startActivityForResult(intent,1);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void on_cate_click(View view)
    {
        findViewById(R.id.cate_domestic).setBackgroundColor(Color.parseColor("#00000000"));
        findViewById(R.id.cate_international).setBackgroundColor(Color.parseColor("#00000000"));
        findViewById(R.id.cate_economy).setBackgroundColor(Color.parseColor("#00000000"));
        findViewById(R.id.cate_culture).setBackgroundColor(Color.parseColor("#00000000"));
        findViewById(R.id.cate_sport).setBackgroundColor(Color.parseColor("#00000000"));
        findViewById(R.id.cate_recommend).setBackgroundColor(Color.parseColor("#00000000"));
        view.setBackgroundColor(Color.parseColor("#FFE689AB"));
        switch(view.getId())
        {
            case(R.id.cate_domestic):
                this.state=1;showList(mapList_d,index[1]);break;
            case(R.id.cate_international):
                this.state=2;showList(mapList_i,index[2]);break;
            case(R.id.cate_economy):
                this.state=3;showList(mapList_e,index[3]);break;
            case(R.id.cate_culture):
                this.state=4;showList(mapList_c,index[4]);break;
            case(R.id.cate_sport):
                this.state=5;showList(mapList_s,index[5]);break;
            case(R.id.cate_recommend):
                this.state=0;show_recommend();break;
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 2){
             labels = data.getIntArrayExtra("ans");
            if(labels[0]==0) findViewById(R.id.cate_domestic).setVisibility(View.GONE);
            else findViewById(R.id.cate_domestic).setVisibility(View.VISIBLE);
            if(labels[1]==0) findViewById(R.id.cate_international).setVisibility(View.GONE);
            else findViewById(R.id.cate_international).setVisibility(View.VISIBLE);
            if(labels[2]==0) findViewById(R.id.cate_economy).setVisibility(View.GONE);
            else findViewById(R.id.cate_economy).setVisibility(View.VISIBLE);
            if(labels[3]==0) findViewById(R.id.cate_culture).setVisibility(View.GONE);
            else findViewById(R.id.cate_culture).setVisibility(View.VISIBLE);
            if(labels[4]==0) findViewById(R.id.cate_sport).setVisibility(View.GONE);
            else findViewById(R.id.cate_sport).setVisibility(View.VISIBLE);
        }
    }
}
