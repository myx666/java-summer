package com.example.hs.mayixiao_news.wxapi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.hs.mayixiao_news.OnResponseListener;
import com.example.hs.mayixiao_news.R;
import com.example.hs.mayixiao_news.WXShare;
import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;

//创建WXEntryActivity,用于和微信App进行交互：
public class WXEntryActivity extends AppCompatActivity implements IWXAPIEventHandler {
    private IWXAPI api;
    private WXShare wxShare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wxentry);
        wxShare = new WXShare(this);
        wxShare.setListener(new OnResponseListener() {
            @Override
            public void onSuccess() {

            }
            @Override
            public void onCancel() {

            }
            @Override
            public void onFail(String message) {

            }
        });
        Log.e("WXEntryActivity","WXEntryActivity");
        WXShare share = new WXShare(this);
        api = share.getApi();
        wxShare.share("111");
       //wxShare.shareUrl(0,this,"https://open.weixin.qq.com","微信分享","I am so crazy");//,"http://avatar.csdn.net/2/C/8/1_small_and_smallworld.jpg");
        //注意：
        // 第三方开发者如果使用透明界面来实现WXEntryActivity，
        // 需要判断handleIntent的返回值，如果返回值为false，
        // 则说明入参不合法未被SDK处理，应finish当前透明界面，避
        // 免外部通过传递非法参数的Intent导致停留在透明界面，
        // 引起用户的疑惑
        try {
            if (!api.handleIntent(getIntent(), this)) {
                finish();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        wxShare.register();
    }

    @Override
    protected void onDestroy() {
        wxShare.unregister();
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.e("onNewIntent","onNewIntent");
        setIntent(intent);
        if (!api.handleIntent(intent, this)) {
            finish();
        }
    }
    @Override
    public void onReq(BaseReq baseReq) {

    }
    @Override
    public void onResp(BaseResp baseResp) {
        Intent intent = new Intent(WXShare.ACTION_SHARE_RESPONSE);
        intent.putExtra(WXShare.EXTRA_RESULT, new WXShare.Response(baseResp));
        sendBroadcast(intent);
        System.out.println("错误类型！！！！！！！！！！！"+baseResp.errCode);
        /*Intent intent1 = new Intent(this, Math.class);
        intent.putExtra("errCode", baseResp.errCode);
        intent.putExtra("errStr", baseResp.transaction);
        startActivity(intent1);*/
        finish();
    }

}