package com.example.hs.mayixiao_news;

import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

public class LabelActivity extends AppCompatActivity {
    private CheckBox[] allbox=new CheckBox[5];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_label);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        allbox[0]=findViewById(R.id.domestic);
        allbox[1]=findViewById(R.id.international);
        allbox[2]=findViewById(R.id.economy);
        allbox[3]=findViewById(R.id.culture);
        allbox[4]=findViewById(R.id.sport);
        Intent intent=getIntent();
        /*int message = intent.getIntExtra("ms",0);
        TextView textView = new TextView(this);
        textView.setTextSize(40);
        textView.setText(message);
        ConstraintLayout layout =  findViewById(R.id.content);
        layout.addView(textView);*/
        //int []receive=intent.getIntArrayExtra("label");
        for(int i=0;i<=4;i++)
        {
            if(intent.getIntArrayExtra("label")[i]==1) allbox[i].setChecked(true);
            else  allbox[i].setChecked(false);
        }
    }

    public void set_button(View view)
    {
        int return_label[]=new int[5];
        Intent intent = new Intent();
        intent.setClass(this, LabelActivity.class);
        for(int i=0;i<=4;i++)
        {
            if(allbox[i].isChecked()) return_label[i]=1;
            else return_label[i]=0;
        }
        intent.putExtra("ans",return_label);
        setResult(2, intent);
        finish();
    }
}
